import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { registerUser } from "../services/User";
import { toast } from "react-toastify";

function Register() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [phone, setPhone] = useState();

  const navigate = useNavigate();
  const onCancel = () => {
    navigate("/");
  };

  const onSubmit = async () => {
    if (name.length == 0) {
      toast.warn("Enter the name");
    } else if (email.length == 0) {
      toast.warn("Enter the email");
    } else if (phone.length == 0) {
      toast.warn("Enter the phone");
    } else if (password.length == 0) {
      toast.warn("Enter the password");
    } else if (confirmPassword.length == 0) {
      toast.warn("Enter the confirm password");
    } else if (password != confirmPassword) {
      toast.warn("Password doesn't match");
    } else {
      const result = await registerUser(name, email, password, phone);
      if (!result) {
        toast.error("Error registering");
      } else {
        if (result.status == "success") {
          toast.success("Successfully Registered");
          navigate("/");
        } else {
          toast.error(result.error);
        }
      }
    }
  };

  return (
    <>
      <div className="container">
        <div className="mb-3">
          <label htmlFor="" className="form-label">
            Name{" "}
          </label>
          <input
            className="form-control"
            type="text"
            onChange={(e) => setName(e.target.value)}
          />
        </div>
        <div className="mb-3">
          <label htmlFor="" className="form-label">
            Phone Number{" "}
          </label>
          <input
            className="form-control"
            type="num"
            onChange={(e) => setPhone(e.target.value)}
          />
        </div>
        <div className="mb-3">
          <label htmlFor="" className="form-label">
            Email{" "}
          </label>
          <input
            className="form-control"
            type="email"
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>
        <div className="mb-3">
          <label htmlFor="" className="form-label">
            Password{" "}
          </label>
          <input
            className="form-control"
            type="password"
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>
        <div className="mb-3">
          <label htmlFor="" className="form-label">
            Confirm Password{" "}
          </label>
          <input
            className="form-control"
            type="password"
            onChange={(e) => setConfirmPassword(e.target.value)}
          />
        </div>
        <div className="mb-3">
          <span>
            Already have an account? <Link to="/">Log in</Link>
          </span>
        </div>
        <div className="mb-3">
          <button className="btn btn-primary ms-3" onClick={onSubmit}>
            Submit
          </button>
          <button className="btn btn-danger ms-4" onClick={onCancel}>
            Cancel
          </button>
        </div>
      </div>
    </>
  );
}

export default Register;
