import axios from "axios";
import React, { useContext, useState } from "react";
import { loginUser } from "../services/User";
import { toast } from "react-toastify";
import { Link, useNavigate } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";

function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const { state, setState } = useContext(AuthContext);

  const navigate = useNavigate();

  const onSubmit = async () => {
    if (email.length == 0) {
      toast.warn("Enter the email");
    } else if (password.length == 0) {
      toast.warn("Enter the password");
    } else {
      const result = await loginUser(email, password);
      if (!result) {
        toast.error("Error logging in");
      } else {
        if (result.status == "success") {
          //console.log(result);
          toast.success("Successfully Logged In");
          const data = result.data;
          sessionStorage.setItem("name", data.name);
          sessionStorage.setItem("token", data.token);
          const name = data.name;
          setState({ name });
          navigate("/home");
        } else {
          toast.error(result.error);
        }
      }
    }
  };

  return (
    <>
      <div className="container">
        <div className="mb-3">
          <label className="form-label" htmlFor="">
            Email{" "}
          </label>
          <input
            className="form-control"
            type="email"
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>
        <div className="mb-3">
          <label className="form-label" htmlFor="">
            Password{" "}
          </label>
          <input
            className="form-control"
            type="password"
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>
        <div>
          <span>
            Create an account? <Link to="/register">Register</Link>
          </span>
        </div>
        <div>
          <button className="btn btn-primary mt-3" onClick={onSubmit}>
            Login
          </button>
        </div>
      </div>
    </>
  );
}

export default Login;
