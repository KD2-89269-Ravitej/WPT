import React, { useContext } from "react";
import { AuthContext } from "../context/AuthContext";

function Home() {
  //const name = sessionStorage.getItem("name");
  const { state, setState } = useContext(AuthContext);
  return (
    <div className="container">
      <main>
        <div className="page-header mt-4 text-primary">
          Welcome to the application{" "}
          <b>
            <i>{state.name}</i>
          </b>
        </div>
      </main>
    </div>
  );
}

export default Home;
