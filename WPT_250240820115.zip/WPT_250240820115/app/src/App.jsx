import React, { useState } from "react";
import { Navigate, Route, Router, Routes } from "react-router-dom";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Home from "./pages/Home";
import { ToastContainer } from "react-toastify";
import { AuthContext } from "./context/AuthContext";

function App() {
  const [state, setState] = useState([]);
  return (
    <>
      <AuthContext value={{ state, setState }}>
        <Routes>
          <Route path="/" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route
            path="/home"
            element={state.name ? <Home /> : <Navigate to="/" />}
          />
        </Routes>
        <ToastContainer />
      </AuthContext>
    </>
  );
}

export default App;
