import axios from "axios";
import { config } from "../config";

export async function registerUser(name, email, password, phone) {
  try {
    const url = `${config.serverURL}/admin/register`;
    const body = {
      name,
      email,
      password,
      phone,
    };

    const result = await axios.post(url, body);
    if (result.status == 200) {
      return result.data;
    } else {
      return null;
    }
  } catch (ex) {
    console.log("Exception : " + ex);
  }
}

export async function loginUser(email, password) {
  try {
    const url = `${config.serverURL}/admin/login`;
    const body = {
      email,
      password,
    };

    const result = await axios.post(url, body);
    if (result.status == 200) {
      return result.data;
    } else {
      return null;
    }
  } catch (ex) {
    console.log("Exception : " + ex);
  }
}
